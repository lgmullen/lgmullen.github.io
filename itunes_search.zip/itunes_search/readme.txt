READ_ME.txt

"I don't OWE YOU like two vowels" - Lil Wayne, A Milli
For the real heads out there who have to pull up rap genius lyrics everytime they hear a song I have
included a button feature that automatically pulls up a song + artist search in a new tab on genius.com
The button is located for each song in the second tab that houses the song ID information!!!!!!